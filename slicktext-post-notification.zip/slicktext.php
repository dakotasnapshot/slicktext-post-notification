<?php
/**
 * Plugin Name: SlickText Post Notification
 * Description: Send post link to SlickText API on post publish using HTTP Basic Authorization with public and private keys.
 * Version: 2.0
 * Author: Dakota Cole
 */

// Add a menu item in the admin menu for the plugin settings
add_action('admin_menu', 'slicktext_plugin_menu');

function slicktext_plugin_menu() {
    add_menu_page('SlickText Settings', 'SlickText Settings', 'manage_options', 'slicktext-settings', 'slicktext_settings_page');
}

// Function to render the settings page
function slicktext_settings_page() {
    ?>
    <div class="wrap">
        <h2>SlickText Settings</h2>
        <?php
        // Display API response notice if available
        $api_response = get_option('slicktext_api_response');
        if ($api_response) {
            ?>
            <div class="notice notice-success is-dismissible">
                <p><strong>SlickText API Response:</strong></p>
                <pre><?php echo esc_html($api_response); ?></pre>
            </div>
            <?php
            // Clear the API response after displaying it
            update_option('slicktext_api_response', '');
        }
        ?>
        <form method="post" action="options.php">
            <?php settings_fields('slicktext_settings_group'); ?>
            <?php do_settings_sections('slicktext-settings'); ?>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Register and define the settings
add_action('admin_init', 'slicktext_plugin_settings');

function slicktext_plugin_settings() {
    register_setting('slicktext_settings_group', 'slicktext_textword');
    register_setting('slicktext_settings_group', 'slicktext_api_key_public');
    register_setting('slicktext_settings_group', 'slicktext_api_key_private');
    register_setting('slicktext_settings_group', 'slicktext_message');
    register_setting('slicktext_settings_group', 'slicktext_api_response');

    add_settings_section('slicktext_main_section', 'Main Settings', 'slicktext_section_text', 'slicktext-settings');

    add_settings_field('slicktext_textword', 'SlickText Textword', 'slicktext_textword_input', 'slicktext-settings', 'slicktext_main_section');
    add_settings_field('slicktext_api_key_public', 'SlickText Public API Key', 'slicktext_api_key_public_input', 'slicktext-settings', 'slicktext_main_section');
    add_settings_field('slicktext_api_key_private', 'SlickText Private API Key', 'slicktext_api_key_private_input', 'slicktext-settings', 'slicktext_main_section');
    add_settings_field('slicktext_message', 'SlickText Message', 'slicktext_message_input', 'slicktext-settings', 'slicktext_main_section');
}

function slicktext_section_text() {
    echo '<p>Enter your SlickText API settings below:</p>';
}

function slicktext_textword_input() {
    $textword = esc_attr(get_option('slicktext_textword'));
    echo "<input type='text' name='slicktext_textword' value='$textword' />";
}

function slicktext_api_key_public_input() {
    $api_key_public = esc_attr(get_option('slicktext_api_key_public'));
    echo "<input type='text' name='slicktext_api_key_public' value='$api_key_public' />";
}

function slicktext_api_key_private_input() {
    $api_key_private = esc_attr(get_option('slicktext_api_key_private'));
    echo "<input type='text' name='slicktext_api_key_private' value='$api_key_private' />";
}

function slicktext_message_input() {
    $message = esc_attr(get_option('slicktext_message'));
    echo "<input type='text' name='slicktext_message' value='$message' />";
}

// Hook to execute the function on post publish
add_action('publish_post', 'send_post_link_to_slicktext');

function send_post_link_to_slicktext($ID) {
    // Get post URL
    $post_url = get_permalink($ID);

    // Get SlickText API settings from settings
    $textword = get_option('slicktext_textword');
    $api_key_public = get_option('slicktext_api_key_public');
    $api_key_private = get_option('slicktext_api_key_private');
    $message = get_option('slicktext_message');

    // SlickText API endpoint
    $api_url = 'https://api.slicktext.com/v1/messages/';

    // Prepare data for the API request
    $data = array(
        'action'   => 'SEND',
        'textword' => $textword,
        'body'     => $message . ' ' . $post_url,
    );

    // Prepare Authorization header with HTTP Basic Authentication
    $headers = array(
        'Authorization' => 'Basic ' . base64_encode($api_key_public . ':' . $api_key_private),
        'Content-Type'  => 'application/x-www-form-urlencoded',
    );

    // Format the data as a URL-encoded string
    $body = http_build_query($data);

    // Send a POST request to SlickText API
    $response = wp_safe_remote_post($api_url, array(
        'headers' => $headers,
        'body'    => $body,
    ));

    // Log the response
    error_log('SlickText API Response: ' . print_r($response, true));

    // Save the API response to display in the settings page
    update_option('slicktext_api_response', print_r($response, true));
}
